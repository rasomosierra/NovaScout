from arduino.app_utils import * 
import socket
import struct
import time

dato1 = 0.0
dato2 = 0.0
# Configuración del emisor
EMISOR_IP = "0.0.0.0"  # Escucha en todas las interfaces de red
PUERTO_SALIDA = 9999

# Direcciones y puertos de los receptores (configura las IPs reales)
CLIENTE1_DIRECCION = ("10.127.163.34", 10001)
CLIENTE2_DIRECCION = ("10.127.163.34", 10002)

# Crear socket UDP
socket_emisor = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)


# Esta función será llamada desde el MCU para sincronizar el comienzo
def linux_started():
    print(" \n\n\n======== Comienza el programa Phyton ========\n ")
    return True
  
# Esta función será llamada desde el MCU 
def recibir_pose(valorX: float, valorY: float, valorTheta: float):
    print(f"x: {valorX:.2f} y: {valorY:.2f} tetha: {valorTheta:.2f}")
    print(" \n\n==================================\n ")
def recibir_modulino(valorModulino: float):
    global dato1
    dato1 = valorModulino
    print(f"Distancia Modulino: {valorModulino/10:.2f} cm")
def recibir_sonar(valorSonar: float):
    global dato2
    dato2 = valorSonar
    print(f"Distancia Sonar: {valorSonar:.2f} cm")
    print(" \n\n==================================\n ")
    time.sleep(1)

Bridge.provide("linux_started", linux_started)
Bridge.provide("recibir_pose", recibir_pose)
Bridge.provide("recibir_modulino", recibir_modulino)
Bridge.provide("recibir_sonar", recibir_sonar)


#App.run()

def loop():
    global dato1
    global dato2
        # Empaquetar los datos float en formato binario ('ff' significa dos floats)
    mensaje_binario = struct.pack('ff', dato1, dato2)
        # Enviar a ambos clientes
    socket_emisor.sendto(mensaje_binario, CLIENTE1_DIRECCION)
    socket_emisor.sendto(mensaje_binario, CLIENTE2_DIRECCION)
    print(f"Distancia Modulino**************************: {dato1/10:.2f} cm")
            
    time.sleep(1)
  
App.run(user_loop=loop)
#App.run()

  

