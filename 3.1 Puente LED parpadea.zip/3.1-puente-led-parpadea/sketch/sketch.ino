#include "Arduino_RouterBridge.h"

uint32_t iloop = 0;

void setup() {
  //Serial.begin(9600); // Inicia comunicación a 9600 baudios
  
  Bridge.begin();
  Bridge.provide("set_led_state", set_led_state);

  pinMode(LED_BUILTIN, OUTPUT);
}

void loop() {
  //Serial.println("¡Hola, Arduino!"); // Imprime un mensaje con salto de línea
  //delay(1000); // Espera un segundo
    //digitalWrite(LED_BUILTIN, HIGH);
    //delay(1000);
    //digitalWrite(LED_BUILTIN, LOW);
    //delay(1000);

    iloop++;
    Bridge.call("fromQRB", iloop); //invoca una funcion del lado linux y espera su resultado
  
    //delay(2000);
}

void set_led_state(bool state) {
    // LOW state means LED is ON
    digitalWrite(LED_BUILTIN, state ? LOW : HIGH);
    //digitalWrite(LED_BUILTIN+1, state2 ? LOW : HIGH);
    //puerto=LED_BUILTIN;
    //Serial.println("hotla");
}



