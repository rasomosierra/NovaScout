
# SPDX-FileCopyrightText: Copyright (C) ARDUINO SRL (http://www.arduino.cc)
#
# SPDX-License-Identifier: MPL-2.0

from arduino.app_utils import *
import time

def fromQRB(data: int):
  print(data)
  time.sleep(2)

Bridge.provide("fromQRB", fromQRB)
  
print("Hello world!")

led_state = False


def loop():
    global led_state
    time.sleep(1)
    led_state = not led_state
    Bridge.call("set_led_state", led_state)

    

App.run(user_loop=loop)
