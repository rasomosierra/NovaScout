#include <Arduino_RouterBridge.h>

// definimos constantes de tiempo en milisegundos
#define diezmilisegundos 10
#define unsegundo 1000
#define cincosegundos 5000
// definimos las entradas en Arduino
// entrada encoder A motor izquierdo (visto desde detras del robot)
#define encAmot_izq  8 
// entrada encoder B motor izquierdo (visto desde detras del robot)
#define encBmot_izq  7 
// entrada encoder A motor derecho (visto desde detras del robot)
#define encAmot_dech  4 
// entrada encoder B motor derecho (visto desde detras del robot)
#define encBmot_dech  2

const int PWM_mot_dech = 9;
const int PWM_mot_izq = 10;
const int Sentido_mot_dech = 11;
const int Sentido_mot_izq = 12;



// Datos necesarios Encoder y rueda
const float pi= 3.14159;
const float diametro=0.0675; //diametro de la rueda en metros
const float resolucion= 880; //pulsos por vuelta del encoder para doble precision (440 simple)
const float dist_entre_ruedas= 0.118;//distancia entre ruedas sobre el eje

// Datos necesarios para fijar un intervalo de tiempo de medicion de velocidad
unsigned long tiempo_anterior = 0; // variable para medir velocidad
unsigned long tiempo_monitor = 0; // variable para intervalo sacar datos por serial monitor
const unsigned long intervalo = unsegundo; // intervalo de tiempo en milisegundos para realizar la medicion de rpm

// variables definidas como volatile para interrupciones
volatile long cont_izq_A = 0;  //contador de pulsos encoder A motor izquierda
volatile long pulsos_inter_izq = 0;  //contador de pulsos encoder A motor izquierda en un intervalo de tiempo

volatile long cont_dech_A = 0;  //contador de pulsos encoder A motor derecho
volatile long pulsos_inter_dech = 0;  //contador de pulsos encoder A motor derecho en un intervalo de tiempo



float dist_rueda_izq = 0; //distancia recorrida por la rueda izquierda
float velocidad_rueda_izq = 0;
float rpm_rueda_izq = 0;

float dist_rueda_dech = 0; //distancia recorrida por la rueda derecho
float velocidad_rueda_dech = 0;
float rpm_rueda_dech = 0;


int valor_PWM_izq = 0;       // Velocidad actual (0-255)
int valor_PWM_dech = 0;       // Velocidad actual (0-255)
unsigned long tiempo_aceleracion = 0; // variable para intervalo aceleracion y deceleracion PWM


void setup() 
{

  Monitor.begin(); //Inicializa el Serial Monitor
  
  pinMode(encAmot_izq, INPUT);
  pinMode(encBmot_izq, INPUT);
  pinMode(encAmot_dech, INPUT);
  pinMode(encBmot_dech, INPUT);
  pinMode(Sentido_mot_izq, OUTPUT);
  pinMode(Sentido_mot_dech, OUTPUT);
  
  //digitalWrite(11, LOW);
  
  attachInterrupt(digitalPinToInterrupt(encAmot_izq), Pulsos_mot_izq, CHANGE);//precision doble flanco de subida y bajada
  attachInterrupt(digitalPinToInterrupt(encAmot_dech), Pulsos_mot_dech, CHANGE);//precision doble flanco de subida y bajada 880 pulsos por vuelta
  //attachInterrupt(digitalPinToInterrupt(encBmot1), encoder, RISING); //precision simple flanco de subida
  
}

void loop() 
{

  unsigned long tiempoActual = millis();
  
  digitalWrite(Sentido_mot_izq, HIGH); // sentido hacia delante M1 nivel alto
  digitalWrite(Sentido_mot_dech, LOW); //sentido hacia delante M2 nivel bajo motor esta alreves

      // Cada diez milisegundos sube la velocidad un punto
    if (millis() - tiempo_aceleracion >= diezmilisegundos) 
    {
      tiempo_aceleracion = millis();
  
      if (valor_PWM_izq < 100) // Seguira incrementando hasta el valor maximo
      {
        valor_PWM_izq++; // Incrementar velocidad
        analogWrite(PWM_mot_izq, valor_PWM_izq); // Aplicar PWM
      }
      if (valor_PWM_dech < 100) // Seguira incrementando hasta el valor maximo
      {
        valor_PWM_dech++; // Incrementar velocidad
        analogWrite(PWM_mot_dech, valor_PWM_dech); // Aplicar PWM
      }
    }
          
          
  Velocidad_Encoders();

  dist_rueda_izq = Distancia_Encoder(cont_izq_A); // distancia recorrida por rueda izquierda (robot visto desde atras)
  dist_rueda_dech = Distancia_Encoder(cont_dech_A); // distancia recorrida por rueda izquierda (robot visto desde atras)

  
  if (tiempoActual - tiempo_monitor >= cincosegundos)  // imprime según el intervalo fijado (5s)
  {
    Monitor.println("Motor izq:          Motor dech:"); //Monitor.println(" ");
    Monitor.print(cont_izq_A); Monitor.print("  ----------  "); Monitor.print(cont_dech_A); Monitor.println("      pulsos"); //Monitor.println(" ");
    Monitor.print(dist_rueda_izq); Monitor.print(" ----------  "); Monitor.print(dist_rueda_dech); Monitor.println("      metros"); //Monitor.println(" ");
    Monitor.print(rpm_rueda_izq); Monitor.print(" ----------  "); Monitor.print(rpm_rueda_dech); Monitor.println("      rpm"); //Monitor.println(" ");
    Monitor.print(velocidad_rueda_izq); Monitor.print(" ----------  "); Monitor.print(velocidad_rueda_dech); Monitor.println("      m/s"); //Monitor.println(" ");
    Monitor.println("-------------------------------");
      
    tiempo_monitor = tiempoActual;
  }
  //delay(2000);  // utilizamos millis() porque delay para el programa

}

void Pulsos_mot_izq() 
{
  cont_izq_A++; // Incrementa el contador en cada flanco de encoder A motor izquierda
  pulsos_inter_izq++;
}

void Pulsos_mot_dech() 
{
  cont_dech_A++; // Incrementa el contador en cada flanco de encoder A motor izquierda
  pulsos_inter_dech++;
}

void Velocidad_Encoders()
{
  unsigned long tiempoActual = millis();
  
  if (tiempoActual - tiempo_anterior >= intervalo) 
  {
    // Calcula RPM motor izquierdo
    rpm_rueda_izq = pulsos_inter_izq / resolucion * (60.0 / (intervalo / 1000.0));
    // Calcula Velocidad m/s rueda izquierda
    velocidad_rueda_izq = (rpm_rueda_izq * pi * diametro) / 60;
    
    // Reiniciar contador
    pulsos_inter_izq = 0;

    // Calcula RPM motor derecho
    rpm_rueda_dech = pulsos_inter_dech / resolucion * (60.0 / (intervalo / 1000.0));
    // Calcula Velocidad m/s rueda derecha
    velocidad_rueda_dech = (rpm_rueda_dech * pi * diametro) / 60;
       
    // Reiniciar contador
    pulsos_inter_dech = 0;

    // actualiza el tiempo
    tiempo_anterior = tiempoActual;
  }
   
}


float Distancia_Encoder(long contador_pulsos)
{

  float distpulso = pi*diametro/resolucion;  //distancia recorrida por cada pulso encoder en metros
                                            //pi*0.06/880 trocito circunferencia rueda 6cm diametro (880pulsos una vuelta)
                                            //cada pulso 
  
  float distancia = contador_pulsos * distpulso;  //distancia en metros recorrida por la rueda
                                                  //cada pulso multiplicado por el trocito de distancia recorrida cada pulso
  
  return distancia; //devuelve el valor de la distancia recorrida

}

