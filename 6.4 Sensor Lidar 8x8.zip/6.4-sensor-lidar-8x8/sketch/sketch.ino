
#include <Arduino_LED_Matrix.h>
#include <Arduino_RouterBridge.h>
#include "Modulino.h"
#include "DFRobot_MatrixLidarQ.h"
    
DFRobot_MatrixLidar_I2C Lidar8x8(0x33); //creamos la un objeto de la clase 
uint16_t buf[64];

void setup(void)
{
  Monitor.begin();
  while(Lidar8x8.begin() != 0) // mientras sea distinto de 0 no inicia
  {
    Monitor.println("begin error !!!!!");
  }
  Monitor.println("begin success"); // incia el sensor
  //configura matrix mode a 8X8
  while(Lidar8x8.setRangingMode(eMatrix_8X8) != 0) // mientras sea distinto de 0 error
  {
    Monitor.println("init error !!!!!");
    delay(1000);
  }
  Monitor.println("init success");
}

void loop(void)
{
 Lidar8x8.getAllData(buf);  // recoge los datos en una variable 
  for(uint8_t i = 0; i < 8; i++){
    Monitor.print("Y");
    Monitor.print(i);
    Monitor.print(": ");
    for(uint8_t j = 0; j < 8; j++){
      Monitor.print(buf[i * 8 + j]);
      Monitor.print(",");
    }
    Monitor.println("");
  }
  Monitor.println("------------------------------");
  delay(2000);
}



