#include <Arduino_RouterBridge.h>

const int encAmot1 = 8; //entrada encoder A motor 1
const int encBmot1 = 7; //entrada encoder B motor 1

volatile long contador = 0; //variable contador pulsos total
volatile long vuelta = 0; //variable contador vueltas rueda
volatile long pulso = 0; //variable contador de pulsos una vuelta


void setup() {

Serial.begin(9600); // Initialize the Monitor

pinMode(encAmot1, INPUT);
pinMode(encBmot1, INPUT);

//attachInterrupt(digitalPinToInterrupt(encBmot1), Lectura_Encoder, RISING); //precision simple flanco de subida
//attachInterrupt(digitalPinToInterrupt(encBmot1), Lectura_Encoder, FALLING); //precision simple flanco de bajada
attachInterrupt(digitalPinToInterrupt(encBmot1), Lectura_Encoder, CHANGE); //doble precision flanco de subida y bajada

}

void loop() {

Serial.print("Numero de pulsos: ");
Serial.println(contador);
Serial.print("Numero de vueltas rueda: ");
Serial.println(vuelta);

 

delay(2000);


}

void Lectura_Encoder()
{
  contador++;
  pulso++;
  
  if (pulso == 880) // cada vuelta son 440 y como es doble precision 880
  {
    pulso = 0;
    vuelta++;
  }
 
}
