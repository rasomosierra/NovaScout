
#include <Arduino_LED_Matrix.h>
#include <Arduino_RouterBridge.h>

//#include "weather_frames.h"






void setup() 
{
    Monitor.begin();
  
  pinMode(LED_BUILTIN, OUTPUT);
  Monitor.println("LED NUMERO:");
    

}

void loop() 
{

    // LOW state means LED is ON
    digitalWrite(LED_BUILTIN, HIGH);
    delay(1000);
    digitalWrite(LED_BUILTIN, LOW);
    delay(1000);

    Monitor.println("LED NUMERO:");
  Monitor.println(LED_BUILTIN);
    //Serial.println(LED_BUILTIN, DEC);

    
  
}
