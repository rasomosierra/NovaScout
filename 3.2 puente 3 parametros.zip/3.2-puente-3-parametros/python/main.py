from arduino.app_utils import * 
import time 


# Esta función será llamada desde el Micro MCU 
def linux_started():
    print(" \n\n\n======== Comienza el programa Phyton ========\n ")
    return True
  
# Esta función será llamada desde el Micro MCU 
def recibir_valor(valorX: float, valorY: float, valorTheta: float):
    #if valorX is None:
        #print("No recibo valores")
        #return
    print(valorX, valorY, valorTheta)
    time.sleep(0.5)

Bridge.provide("linux_started", linux_started) # Expone una funcion de Linux para que pueda ser llamada por el Micro MCU
Bridge.provide("recibir_valor", recibir_valor) # Expone una funcion de Linux para que pueda ser llamada por el Micro MCU


App.run()
  
#def loop(): 

   #time.sleep(1) 
  
#App.run(user_loop=loop)

