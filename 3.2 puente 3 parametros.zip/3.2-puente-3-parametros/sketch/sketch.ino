#include <Arduino_RouterBridge.h> 

//RouterBridge bridge; 
float x=0; // Ejemplo: un dato cualquiera
float y=0;
float theta=0;
unsigned long tiempo = 0;

void setup() 
{ 
  Bridge.begin(); 
  //Serial.begin(115200); 

  //Esperamos a que comience Python para empezar a enviar datos
  //Hasta que no recibimos el true de la funcion de Linux "linux_started" no se sigue
  boolean start = false;
  while(!start)
  {
    Bridge.call("linux_started").result(start);  // Invoca una función en el lado de Linux y espera un resultado (bloquea el programa)
                                                //Debe estar siempre al final para que funcione bien
  }
  
} 

void loop() 
{ 
  if( millis()-tiempo >= 500)
  {
    x++;
    y= x+1;
    theta= y+1;
    tiempo = millis();
    
    Bridge.notify("recibir_valor", x, y, theta); // Invoca una función en el lado de Linux sin esperar una respuesta (activar y olvidar)
                                                  //Debe estar siempre al final para que funcione bien
  }
    
}




