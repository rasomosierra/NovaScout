

#include <Arduino_LED_Matrix.h>
#include <Arduino_RouterBridge.h>

#define STAT  13 

ArduinoLEDMatrix matrix;
// Usa una matriz bidimensional para representar una matriz LED de 12x8.
byte frame1[8][13] = {
  { 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0 },
  { 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0 },
  { 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0 },
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0 },
  { 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0 },
  { 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0 },
  { 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0 },
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
};
uint8_t frame2[104] = {
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ,
   0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0 ,
   0, 0, 1, 7, 1, 7, 1, 7, 1, 7, 1, 1, 0 ,
   0, 0, 1, 7, 1, 7, 1, 7, 1, 7, 1, 1, 0 ,
   0, 0, 1, 7, 1, 7, 1, 7, 1, 7, 1, 1, 0 ,
   0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0 ,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 
};


void setup() {
  matrix.begin();
  matrix.setGrayscaleBits(3);
  //matrix.clear();

  pinMode(STAT, INPUT);

  //Bridge.begin();
}

void loop() 
{

  int estado = digitalRead(STAT);  // pin estado LOW si esta cargando la bateria

  if (estado == LOW) 
  {
    matrix.renderBitmap(frame1,8,13);  // Mostrar el patrón en la matriz LED en este caso una flecha
    shiftLeftLoop(frame1);  // mover la flecha hacia la izquierda cuando el robot carga
  }
  else
  {
    matrix.draw(frame2);  // Mostrar una bateria
    //matrix.clear();
  }
    
  
  delay(200); // un segundo son 1000

}

// MOVER TEXTO HACIA LA DERECHA UNA COLUMNA
void shiftRightLoop(byte frame[8][13]) {
    for (int y = 0; y < 8; y++) {
        byte last = frame[y][12];  // guardamos la última columna
        for (int x = 12; x > 0; x--) {
            frame[y][x] = frame[y][x - 1];
        }
        frame[y][0] = last;        // la columna que salió vuelve al inicio
    }
}
// MOVER TEXTO HACIA LA IZQUIERDA UNA COLUMNA
void shiftLeftLoop(byte frame[8][13]) {
    for (int y = 0; y < 8; y++) {
        byte first = frame[y][0];
        for (int x = 0; x < 12; x++) {
            frame[y][x] = frame[y][x + 1];
        }
        frame[y][12] = first;
    }
}


