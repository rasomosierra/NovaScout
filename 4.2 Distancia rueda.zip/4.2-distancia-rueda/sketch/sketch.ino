#include <Arduino_RouterBridge.h>

const int encAmot_izq = 8; //entrada encoder A motor izquierdo (visto desde detras del robot)
const int encBmot_izq = 7; //entrada encoder B motor izquierdo (visto desde detras del robot)

volatile long cont_izq_A = 0;  //contador de pulsos encoder A motor izquierda 
volatile float dist_rueda_izq = 0; //distancia recorrida por la rueda

void setup() 
{

  Monitor.begin(); //Inicializa el Monitor
  
  pinMode(encAmot_izq, INPUT);
  pinMode(encBmot_izq, INPUT);
  
  //attachInterrupt(digitalPinToInterrupt(encAmot_izq), Distancia_Encoder, RISING);//precision simple flanco de subida  440 pulsos
  attachInterrupt(digitalPinToInterrupt(encAmot_izq), Distancia_Encoder, CHANGE); //precision doble flanco de subida y bajada 880 pulsos
  
}

void loop() 
{

  Monitor.print("Numero de pulsos: ");
  Monitor.println(cont_izq_A);
  Monitor.print("Distancia en metros: ");
  Monitor.println(dist_rueda_izq);
  delay(2000);

}

void Distancia_Encoder()
{

  float pi= 3.1416;
  float diametro=0.0675; //diametro en metros
  float resolucion= 880; //pulsos por vuelta del encoder
  float distpulso= pi*diametro/resolucion;  //distancia recorrida por cada pulso encoder en metros
                                            //pi*0.0675/880 trocito circunferencia rueda 6cm diametro (880 pulsos una vuelta)
                                            //cada pulso 
  
  cont_izq_A++;

  dist_rueda_izq = cont_izq_A * distpulso;  //distancia en metros recorrida por la rueda izquierda (visto desde detras del robot)
                                            //cada pulso multiplicado por distancia recorrida cada pulso
   
}

