
//#include <Arduino_LED_Matrix.h>
#include <Arduino_RouterBridge.h>
#include "Modulino.h"

// Creamos un objeto distancia
ModulinoDistance distance;
int measureAnt = -1; //valor para comparar, si es igual no sacar por pantalla

void setup() {
  Monitor.begin();

  // Iniciamos Modulino system y Sensor de distancia
  Modulino.begin();
  distance.begin();
}

void loop() {
  if (distance.available()) 
  {
    int measure = distance.get(); //devuelve la distancia en mm
    
    if(abs(measure - measureAnt) > 5)  // solo si imprime puerto serie si la diferencia entre medidas es más de 5 mm
    {  
      Monitor.print("Distancia: "); Monitor.print(measure/10); Monitor.println(" cm");
      measureAnt = measure;
    }
     
  }
  delay(100); // cada 100 milisegundos
}