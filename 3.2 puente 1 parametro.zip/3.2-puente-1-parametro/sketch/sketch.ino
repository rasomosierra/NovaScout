#include <Arduino_RouterBridge.h> 

 
float x = 0; // Ejemplo: un dato cualquiera
unsigned long tiempo = 0;

void setup() 
{ 
  Bridge.begin(); 
  //Serial.begin(115200); 
  
} 

void loop() 
{ 
  if(millis() - tiempo >= 2000)
  {
    x++;
    Bridge.notify("recibir_valor", x);
    tiempo = millis();
  }
    
}




