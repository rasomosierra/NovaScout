from arduino.app_utils import * 
import time 


# Esta función será llamada desde el MCU 


def recibir_valor(valor: float):
    print("Valor recibido:", valor)
    time.sleep(0.5)

Bridge.provide("recibir_valor", recibir_valor) 

App.run()

#def loop(): 

   #time.sleep(1) 
  
#App.run(user_loop=loop)