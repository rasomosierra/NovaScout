from arduino.app_utils import * 
import socket
import struct
import time

#Defino variables globales
dato1 = 0.0
dato2 = 0.0
x = 0.0
y = 0.0
theta = 0.0
A2 = 0.0
A3 = 0.0
A4 = 0.0
A5 = 0.0
array = [0 for _ in range(64)]

# Configuración del emisor
EMISOR_IP = "0.0.0.0"  # Escucha en todas las interfaces de red
PUERTO_SALIDA = 9999

# Direccion y puertos del PC
CLIENTE1_DIRECCION = ("10.127.163.34", 10001)
CLIENTE2_DIRECCION = ("10.127.163.34", 10002)
CLIENTE3_DIRECCION = ("10.127.163.34", 10003)
CLIENTE4_DIRECCION = ("10.127.163.34", 10004)
CLIENTE5_DIRECCION = ("10.127.163.34", 10005)
# Direccion y puertos del MOVIL
CLIENTE6_DIRECCION = ("10.127.163.249", 10006)


# Crear socket UDP
socket_emisor = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)



# Esta función será llamada desde el MCU para sincronizar el comienzo
def linux_started():
    print(" \n\n\n======== Comienza el programa Phyton ========\n ")
    return True
  
# Esta función será llamada desde el MCU 
def recibir_pose(valorX: float, valorY: float, valorTheta: float):
    global x
    global y
    global theta
    x = valorX
    y = valorY
    theta = valorTheta
    #print(f"x: {valorX:.2f} y: {valorY:.2f} tetha: {valorTheta:.2f}")
    #print(" \n\n==================================\n ")
def recibir_modulino(valorModulino: float):
    global dato1
    dato1 = valorModulino
    #print(f"Distancia Modulino: {valorModulino/10:.2f} cm")
def recibir_sonar(valorSonar: float):
    global dato2
    dato2 = valorSonar
    #print(f"Distancia Sonar: {valorSonar:.2f} cm")
    #print(" \n\n==================================\n ")
def recibir_siguelineas(valorA2: float, valorA3: float, valorA4: float, valorA5: float):
    global A2
    global A3
    global A4
    global A5
    A2 = valorA2
    A3 = valorA3
    A4 = valorA4
    A5 = valorA5
    #print(f"A2: {valorA2*0.004882:.2f} A3: {valorA3*0.004882:.2f} A4: {valorA4*0.004882:.2f} A5: {valorA5*0.004882:.2f}")
    #print(" \n\n==================================\n ")
def recibir_Lidar8X8(datos):
    global array
    array[:] = datos
    #print(len(datos))
    #print(datos[0])
    
time.sleep(1)

Bridge.provide("linux_started", linux_started)
Bridge.provide("recibir_pose", recibir_pose)
Bridge.provide("recibir_modulino", recibir_modulino)
Bridge.provide("recibir_sonar", recibir_sonar)
Bridge.provide("recibir_siguelineas", recibir_siguelineas)
Bridge.provide("recibir_Lidar8X8", recibir_Lidar8X8)


#App.run()

def loop():
    
    global dato1
    global dato2
    global x
    global y
    global theta
    global A2
    global A3
    global A4
    global A5
    global array
    # Empaquetar los datos float en formato binario ('ff' significa dos floats)
    mensaje_binario1 = struct.pack('ff', dato1, dato2)
    mensaje_binario2 = struct.pack('fff', x, y, theta)
    mensaje_binario3 = struct.pack('ffff', A2, A3, A4, A5)
    mensaje_binario4 = struct.pack('64H', *array)
    # Enviar datos al PC
    socket_emisor.sendto(mensaje_binario1, CLIENTE1_DIRECCION)
    socket_emisor.sendto(mensaje_binario1, CLIENTE2_DIRECCION)
    socket_emisor.sendto(mensaje_binario2, CLIENTE3_DIRECCION)
    socket_emisor.sendto(mensaje_binario3, CLIENTE4_DIRECCION)
    socket_emisor.sendto(mensaje_binario4, CLIENTE5_DIRECCION)
    # Enviar datos al MOVIL
    socket_emisor.sendto(mensaje_binario1, CLIENTE6_DIRECCION)

    print(f"x: {x:.2f} y: {y:.2f} tetha: {theta:.2f}")
    print(" ================================== ")
    print(f"Distancia Modulino: {dato1/10:.2f} cm")
    print(" ================================== ")
    print(f"Distancia Sonar: {dato2:.2f} cm")
    print(" ================================== ")
    print(f"A2: {A2*0.004882:.2f} A3: {A3*0.004882:.2f} A4: {A4*0.004882:.2f} A5: {A5*0.004882:.2f}")
    print(" ================================== ")
    print(f"LIDAR 8X8\n")
    for i in range(8):
        fila = array[i * 8:(i + 1) * 8]
        print(f"Y{i}: {fila[::-1]}")
    print(" ================================== ")
    
    time.sleep(1)
  
App.run(user_loop=loop)


  

