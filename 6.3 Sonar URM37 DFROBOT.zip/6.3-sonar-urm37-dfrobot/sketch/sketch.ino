
#include <Arduino_LED_Matrix.h>
#include <Arduino_RouterBridge.h>
#include "Modulino.h"

// # Conexiones:
// #       Vcc (Arduino)      -> Pin 1 VCC (URM V5.0)
// #       GND (Arduino)      -> Pin 2 GND (URM V5.0)
// #       Pin 3 (Arduino)    -> Pin 3 ECHO (URM V5.0)
// #       Pin 1 TX1 (Arduino)  -> Pin 4 RXD (URM V5.0)
// #       Pin 0 RX0 (Arduino)  -> Pin 5 TXD (URM V5.0)
// # Modo de trabajo:  Automatic measurement model.

int URECHO = 3; // PWM Output 0－50000us，cada 50us que tarda en llegar es 1cm
unsigned int Distance = 0;
unsigned int DistanceAnt = 0;
uint8_t AutomaticModelCmd[4] = {0x44, 0x02, 0xaa, 0xf0}; // Configuracion para Automatic measurement model

void setup() 
{               
  //Serial.begin(9600);
  Monitor.begin();           // Serial initialization 
  AutomaticModelSetup();        //Automatic measurement model set
  delay(5000);                   // wait for sensor setup
  
}
void loop()
{
  AutomaticMeasurement();
  delay(100);
}
                                                                              // funcion para medir lo largo que es el pulso en microsegundos
unsigned long pulseIn_Q(int pin, bool state, unsigned long timeout = 1000000) // timeout 1 segundo porque son microsegundos (us)
                                                                              // recordar que cada 50us es un centimetro
{
    unsigned long start = micros();

    // Esperar a que empiece el pulso
    while (digitalRead(pin) != state) 
    {
        if (micros() - start > timeout) // timeout 1 segundo
        {
          Monitor.print("Esperando a empiece pulso");
          return 0;
        }
    }

    // Pulso ha empezado
    unsigned long pulseStart = micros();

    // Esperar a que termine el pulso
    while (digitalRead(pin) == state) 
    {
        if (micros() - pulseStart > timeout) return 0;
    }

    return micros() - pulseStart; // enviamos la duración del pulso en microsegundos (us)
}

void AutomaticModelSetup(void)
{
  pinMode(URECHO, INPUT);                     
  for (int i = 0; i < 4; i++)
  {
    Monitor.write(AutomaticModelCmd[i]);// Enviamos Automatic measurement model command {0x44, 0x02, 0xaa, 0xf0}
  }
}
void AutomaticMeasurement(void)
{
  long DistanceMeasured = pulseIn_Q(URECHO, LOW);
  if (DistanceMeasured >= 50000) // the reading is invalid.
  {
    Monitor.print("Invalid");
  }
  else
  {
    Distance = DistanceMeasured / 50;       // recordar que cada 50us es un centimetro
      if (abs(Distance - DistanceAnt) > 3 )
      {
          Monitor.print("Distance=");
          Monitor.print(Distance);
          Monitor.println("cm");
          DistanceAnt = Distance;
      }
  }  
  
}
