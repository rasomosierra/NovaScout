
#include <Arduino_LED_Matrix.h>
#include <Arduino_RouterBridge.h>


void setup() 
{
  Monitor.begin(); // Iniciar comunicación serial
}

void loop() 
{
  int sensorValueA4 = analogRead(A3); // Leer pin analógico A0
  int sensorValueA5 = analogRead(A4); // Leer pin analógico A0

  // la salida anoligica obtiene valores desde 0 a 1023
  // Si quiero voltaje 0 a 5v multiplico 1023*0,004882 = 5v
  // Si quiero voltaje 0 a 3,3v multiplico 1023*0,00323 = 3,3v

  Monitor.print("S1      "); Monitor.println(" S2");
  Monitor.print(sensorValueA4*0.004882); Monitor.print(" V  "); Monitor.print(sensorValueA5*0.004882); Monitor.println(" V"); // Mostrar valor en Monitor Serie  
  Monitor.println("  ");
 
  
  delay(2000); // Pequeña pausa
}