#include <Arduino_RouterBridge.h>

// definimos las entradas en Arduino
const int encAmot_izq = 8; //entrada encoder A motor izquierdo (visto desde detras del robot)
const int encBmot_izq = 7; //entrada encoder B motor izquierdo (visto desde detras del robot)

// Datos necesarios Encoder y rueda
const float pi= 3.1416;
const float diametro=0.0675; //diametro de la rueda en metros
const float resolucion= 880; //pulsos por vuelta del encoder Motor izq
const float dist_entre_ruedas= 0.118;//distancia entre ruedas sobre el eje

// Datos necesarios para fijar un intervalo de tiempo de medicion de velocidad
unsigned long tiempo_anterior = 0; // variable para medir velocidad
const unsigned long intervalo = 3000; // intervalo de tiempo en milisegundos para realizar la medicion de rpm

volatile long cont_izq_A = 0;  //contador de pulsos encoder A motor izquierda
volatile long pulsos_contados = 0;  //contador de pulsos 
volatile float dist_rueda_izq = 0; //distancia recorrida por la rueda

void setup() 
{

  Monitor.begin(); //Inicializa el Serial Monitor
  
  pinMode(encAmot_izq, INPUT);
  pinMode(encBmot_izq, INPUT);
  
  //attachInterrupt(digitalPinToInterrupt(encAmot_izq), Contar_Pulsos, RISING);//precision simple flanco de subida
  attachInterrupt(digitalPinToInterrupt(encAmot_izq), Contar_Pulsos, CHANGE); //precision doble flanco de subida y bajada
  
}

void loop() 
{

  //Distancia_Encoder();
  Velocidad_Encoder();
  
  //delay(2000);

}

void Contar_Pulsos() 
{
  cont_izq_A++; // Incrementa el contador en cada flanco de encoder A motor izquierda
  pulsos_contados++;
}

void Velocidad_Encoder()
{
  if (millis() - tiempo_anterior >= intervalo) 
  {
    // Calcula RPM
    float rpm = pulsos_contados / resolucion * (60.0 / (intervalo / 1000.0));
    // Calcula Velocidad m/s
    float velocidad = (rpm * pi * diametro) / 60;
    
    Monitor.print("RPM: ");
    Monitor.println(rpm);
    Monitor.print("Velocidad en m/s: ");
    Monitor.println(velocidad);
    
    // Reiniciar contador y actualizar tiempo
    pulsos_contados = 0;
    tiempo_anterior = millis();
  }
   
}

void Distancia_Encoder()
{

  float distpulso= pi*diametro/resolucion;  //distancia recorrida por cada pulso encoder en metros
                                            //pi*0.06/374 trocito circunferencia rueda 6cm diametro (374pulsos una vuelta)
                                            //cada pulso 
  
  dist_rueda_izq = cont_izq_A * distpulso;  //distancia en metros recorrida por la rueda izquierda (visto desde detras del robot)
                                            //cada pulso multiplicado por distancia recorrida cada pulso
  
  if (millis() - tiempo_anterior >= intervalo) 
  {
    Monitor.print("Numero de pulsos: ");
    Monitor.println(cont_izq_A);
    Monitor.print("Distancia en metros: ");
    Monitor.println(dist_rueda_izq);
  }

}
