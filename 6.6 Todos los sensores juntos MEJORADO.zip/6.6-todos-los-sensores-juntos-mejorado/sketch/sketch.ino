
#include <Arduino_LED_Matrix.h>
#include <Arduino_RouterBridge.h>
#include "Modulino.h"
#include "DFRobot_MatrixLidarQ.h"

// Definimos constantes de tiempo en milisegundos
#define unmilisegundo 10
#define diezmilisegundos 10
#define veintemilisegundos 20
#define doscientosmilisegundos 200
#define unsegundo 1000
#define dossegundos 2000
#define cincosegundos 5000

unsigned long tiempo_monitor = 0; // variable para intervalo sacar datos por serial monitor
unsigned long tiempo_lectura = 0; // variable para intervalo sacar datos por serial monitor

int sensorValueA2 = 0; // Leer pin analógico A2
int sensorValueA3 = 0; // Leer pin analógico A3
int sensorValueA4 = 0; // Leer pin analógico A4
int sensorValueA5 = 0; // Leer pin analógico A5

int estado = 0;  // estado pin 13 entrada fuente alimentacion (LOW conectada, HIGH desconectada)

// pin de estado de fuente de alimentación conectada
#define STAT  13   

// Usa una matriz bidimensional para representar una matriz LED de 12x8.
ArduinoLEDMatrix matrix;
byte frame1[8][13] = {
  { 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0 },
  { 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0 },
  { 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0 },
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0 },
  { 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0 },
  { 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0 },
  { 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0 },
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
};
uint8_t frame2[104] = {
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ,
   0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0 ,
   0, 0, 1, 7, 1, 7, 1, 7, 1, 7, 1, 1, 0 ,
   0, 0, 1, 7, 1, 7, 1, 7, 1, 7, 1, 1, 0 ,
   0, 0, 1, 7, 1, 7, 1, 7, 1, 7, 1, 1, 0 ,
   0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0 ,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 
};

// Creamos un objeto Modulino distance
ModulinoDistance distance;
int measure = 0;
//int measureAnt = -1; //valor para comparar, si es igual no sacar por pantalla

// Creamos las variables Sensor Sonar URM37
// # Conexiones:
// #       Vcc (Arduino)      -> Pin 1 VCC (URM V5.0)
// #       GND (Arduino)      -> Pin 2 GND (URM V5.0)
// #       Pin 3 (Arduino)    -> Pin 3 ECHO (URM V5.0)
// #       Pin 1 TX1 (Arduino)  -> Pin 4 RXD (URM V5.0)
// #       Pin 0 RX0 (Arduino)  -> Pin 5 TXD (URM V5.0)
// # Modo de trabajo:  Automatic measurement model.

int URECHO = 3; // PWM Output 0－50000us，cada 50us que tarda en llegar es 1cm
unsigned int Distance = 0;
//unsigned int DistanceAnt = 0;
uint8_t AutomaticModelCmd[4] = {0x44, 0x02, 0xaa, 0xf0}; // Configuracion para Automatic measurement model

// Creamos un objeto Lidar8x8
DFRobot_MatrixLidar_I2C Lidar8x8(0x32); //creamos la un objeto de la clase 
uint16_t buf[64];

void setup(void)
{
  // Iniciamos Serial Monitor
        Monitor.begin();

  // Iniciamos Modulino system y Sensor de distancia
        Modulino.begin();
        distance.begin();

  // Iniciamos URM37
        AutomaticModelSetup();        //Automatic measurement model set
        delay(3000);                   // wait for sensor setup

  // Iniciamos la matriz led de Arduino UNO Q
        matrix.begin();
        matrix.setGrayscaleBits(3);
        pinMode(STAT, INPUT);  // configuramos el pin 13 como entrada si esta enchufado o no la fuente de alimentación

  // Iniciamos Lidar8x8
        while(Lidar8x8.begin() != 0) // mientras sea distinto de 0 no inicia
        {
          Monitor.println("begin error !!!!!");
        }
        Monitor.println("begin success"); // incia el sensor
        //configura matrix mode a 8X8
        while(Lidar8x8.setRangingMode(eMatrix_8X8) != 0) // mientras sea distinto de 0 error
        {
          Monitor.println("init error !!!!!");
          delay(1000);
        }
        Monitor.println("init success");
  
}

void loop(void)
{
  

      unsigned long tiempoActual = millis();

  // *******************************************************************************************
  // intervalo fijado para lectura de sensores 200 milisegundos para no sobrecargar microprocesador
  
      if (tiempoActual - tiempo_lectura >= doscientosmilisegundos)  
      {

          // *******************************************************************************************
          // Sensores Sigue-Lineas entradas A2 A3 A4 A5
          // Robot con motores hacia atras
        
              sensorValueA2 = analogRead(A2); // Leer pin analógico A2
              sensorValueA3 = analogRead(A3); // Leer pin analógico A3
              sensorValueA4 = analogRead(A4); // Leer pin analógico A4
              sensorValueA5 = analogRead(A5); // Leer pin analógico A5
        
              // la salida anoligica obtiene valores desde 0 a 1023
              // Si quiero voltaje 0 a 5v multiplico 1023*0,004882 = 5v
              // Si quiero voltaje 0 a 3,3v multiplico 1023*0,00323 = 3,3v
        
        
          // *******************************************************************************************
          // Sensor Lidar 64 puntos (8x8)
          
              Lidar8x8.getAllData(buf);  // recoge los datos en una variable buf[64]
          
          // *******************************************************************************************
          // Sensor Modulino Distance
              if (distance.available()) 
              {
                      measure = distance.get(); //devuelve la distancia en mm
              }  
              
          // *******************************************************************************************
          // Sensor Sonar URM37
              AutomaticMeasurement();  // recogemos medidas en cm
        
            
          // *******************************************************************************************
          // Si el pin 13 esta a nivel bajo y si es asi se enciende la matriz led estado de carga
        
              estado = digitalRead(STAT);  // pin estado LOW si esta cargando la bateria
        
              if (estado == LOW) 
              {
                    matrix.renderBitmap(frame1,8,13);  // Mostrar el patrón en la matriz LED en este caso una flecha
                    shiftLeftLoop(frame1);  // mover la flecha hacia la izquierda cuando el robot carga
              }
              else
              {
                    matrix.draw(frame2);  // Mostrar una bateria en la matriz led
                   //matrix.clear();
              }

      
        tiempo_lectura = tiempoActual;
        
      }
    

  // *******************************************************************************************
  // imprime por monitor serie según el intervalo fijado
  
      if (tiempoActual - tiempo_monitor >= dossegundos)  
      {
          
          // Imprimimos por pantalla los valores de los sensores sigue-lineas
              Monitor.print("A2      "); Monitor.print("A3      "); Monitor.print("A4      "); Monitor.println(" A5");
              Monitor.print(sensorValueA2*0.004882); Monitor.print(" V  "); 
              Monitor.print(sensorValueA3*0.004882); Monitor.print(" V  "); // Mostrar valor en Monitor Serie 
              Monitor.print(sensorValueA4*0.004882); Monitor.print(" V  "); // Si quiero voltaje 0 a 5v multiplico 1023*0,004882 = 5v
              Monitor.print(sensorValueA5*0.004882); Monitor.println(" V"); // Si quiero voltaje 0 a 3,3v multiplico 1023*0,00323 = 3,3v
              Monitor.println("  ");
              Monitor.println("------------------------------");
          // Imprimimos por pantalla el valor del sensor Modulino Distance
              Monitor.print("Distancia Modulino: "); Monitor.print(measure/10); Monitor.println(" cm");
              Monitor.println("------------------------------");
        
          // Imprimimos por pantalla el valor del sensor Sonar URM37
              Monitor.print("Distancia Sonar = ");
              Monitor.print(Distance);
              Monitor.println("cm");
              Monitor.println("------------------------------");
        
          // Imprimimos por pantalla los valores del sensor Lidar 8x8
              for(uint8_t i = 0; i < 8; i++)
              {
                  Monitor.print("Y");
                  Monitor.print(i);
                  Monitor.print(": ");
                  for(uint8_t j = 0; j < 8; j++){
                    Monitor.print(buf[i * 8 + j]);
                    Monitor.print(",");
                  }
                  Monitor.println("");
              }
              Monitor.println("  ");
              Monitor.println("------------------------------");
          
          // Imprimimos por pantalla los valores del sensor Lidar 8x8
        
              if (estado == LOW) 
              {
                    Monitor.println("Fuente conectada, batería cargador ... ");
                    Monitor.println("------------------------------");
              }
              else
              {
                    Monitor.println("Robot autonomo, fuente desconectada");
                    Monitor.println("------------------------------");
              }
  
        tiempo_monitor = tiempoActual;
      }

  
      //delay(2000);  // no se puede utilizar delay porque para el programa
}



// *******************************************************************************************
// Funciones de Sensor Sonar URM37
                                                                              // funcion para medir lo largo que es el pulso en microsegundos
unsigned long pulseIn_Q(int pin, bool state, unsigned long timeout = 1000000) // timeout 1 segundo porque son microsegundos (us)
                                                                              // recordar que cada 50us es un centimetro
{
    unsigned long start = micros();

    // Esperar a que empiece el pulso
    while (digitalRead(pin) != state) 
    {
        if (micros() - start > timeout) // timeout 1 segundo
        {
          Monitor.print("Esperando a empiece pulso");
          return 0;
        }
    }

    // Pulso ha empezado
    unsigned long pulseStart = micros();

    // Esperar a que termine el pulso
    while (digitalRead(pin) == state) 
    {
        if (micros() - pulseStart > timeout) return 0;
    }

    return micros() - pulseStart; // enviamos la duración del pulso en microsegundos (us)
}

void AutomaticModelSetup(void)
{
  pinMode(URECHO, INPUT);                     
  for (int i = 0; i < 4; i++)
  {
    Monitor.write(AutomaticModelCmd[i]);// Enviamos Automatic measurement model command {0x44, 0x02, 0xaa, 0xf0}
  }
}
void AutomaticMeasurement(void)
{
  long DistanceMeasured = pulseIn_Q(URECHO, LOW); // recogemos la duración del pulso en microsegundos
  if (DistanceMeasured >= 50000) // Si la duración del pulso supera los 0,05 segundos la medida no vale (>10metros).
  {
    Monitor.print("Invalid");
  }
  else
  {
    Distance = DistanceMeasured / 50;       // recordar que cada 50us es un centimetro
      //if (abs(Distance - DistanceAnt) > 3 )  // solo imprime la distancia si a cambiado en 3 unidades
      //{
          //Monitor.print("Distancia Sonar=");
          //Monitor.print(Distance);
          //Monitor.println("cm");
          //Monitor.println("------------------------------");
          //DistanceAnt = Distance;
      //}
  }  
  
}

// *******************************************************************************************
// MOVER TEXTO HACIA LA DERECHA UNA COLUMNA
void shiftRightLoop(byte frame[8][13]) {
    for (int y = 0; y < 8; y++) {
        byte last = frame[y][12];  // guardamos la última columna
        for (int x = 12; x > 0; x--) {
            frame[y][x] = frame[y][x - 1];
        }
        frame[y][0] = last;        // la columna que salió vuelve al inicio
    }
}
// MOVER TEXTO HACIA LA IZQUIERDA UNA COLUMNA
void shiftLeftLoop(byte frame[8][13]) {
    for (int y = 0; y < 8; y++) {
        byte first = frame[y][0];
        for (int x = 0; x < 12; x++) {
            frame[y][x] = frame[y][x + 1];
        }
        frame[y][12] = first;
    }
}




