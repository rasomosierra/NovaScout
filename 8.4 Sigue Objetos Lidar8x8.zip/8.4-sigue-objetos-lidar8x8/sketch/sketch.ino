#include <Arduino_LED_Matrix.h>
#include <array>
#include <Arduino_RouterBridge.h>
#include "Modulino.h"
#include "DFRobot_MatrixLidarQ.h"

// Definimos constantes de tiempo en milisegundos
#define unmilisegundo 1
#define diezmilisegundos 10
#define veintemilisegundos 20
#define cienmilisegundos 100
#define doscientosmilisegundos 200
#define unsegundo 1000
#define dossegundos 2000
#define cincosegundos 5000
// Definimos las entradas en Arduino (visto desde detras del robot)
// Entrada encoder 
#define encAmot_izq  8 
#define encBmot_izq  7 
#define encAmot_dech  4 
#define encBmot_dech  2
// pin 13 de estado de fuente de alimentación conectada
#define STAT  13
// Definimos las salidas en Arduino
// Salidas PWM
#define PWM_mot_dech  9
#define PWM_mot_izq  10
#define Sentido_mot_dech  11
#define Sentido_mot_izq  12
// Definimos las variables entrada analogicas del sensor sigue-lineas
int sensorValueA2 = 0; // Leer pin analógico A2
int sensorValueA3 = 0; // Leer pin analógico A3
int sensorValueA4 = 0; // Leer pin analógico A4
int sensorValueA5 = 0; // Leer pin analógico A5
// estado pin 13 entrada fuente alimentacion (LOW conectada, HIGH desconectada)
int estado = 0;  

//  ARDUINO Q
//
//                  +--------\/-------+
//                  |                 |32  D21  SCL
//                  |                 |31  D20  SDA
//                  |                 |30  AREF 
//           BOOT  1|                 |29  GND 
//          IOREF  2|                 |28  D13  SCK
//          RESET  3|                 |27  D12  MISO
//       +3V3 OUT  4|                 |26  D11  MOSI  PWM+
//        +5V OUT  5|                 |25  D10  SS    PWM+
//            GND  6|                 |24  D9         PWM+
//            GND  7|                 |23  D8
//     (7-24V)VIN  8|                 |22  D7
//                  |                 |21  D6         PWM+
//    DCA0  A0D14  9|                 |20  D5         PWM+
//    DCA1  A1D15 10|  QWIIC          |19  D4 
//          A2D16 11|  GND            |18  D3         PWM+
//          A3D17 12| +3V3(OUT)       |17  D2 
//     SDA  A4D18 13|  SDA            |16  D1  USART1_TX
//     SCL  A5D19 14|  SCL            |15  D0  USART1_RX
//                  +-----------------+
//                     ||||



//----------------------------------------------------------------------------------------------
// Datos necesarios para fijar un intervalo de tiempo de medicion
unsigned long tiempo_anterior = 0; // variable para intervalo para medir velocidad
unsigned long tiempo_anterior2 = 0; // variable para intervalo para medir distancia diferencial
unsigned long tiempo_anterior3 = 0; // variable para intervalo para medir distancia diferencial
unsigned long tiempo_monitor = 0; // variable para intervalo sacar datos por serial monitor
unsigned long retraso_motores = 2000; // variable para meter un retardo al incio de los motores cuando empieza el programa
unsigned long tiempo_lectura = 0; // variable para intervalo de lectura de sensores
unsigned long tiempo_lectura_Sigue = 0; // variable para intervalo de lectura de sensores

//----------------------------------------------------------------------------------------------
// Datos necesarios Encoder y rueda
const float pi= 3.14159;
const float diametro= 0.0675; //diametro de la rueda en metros
const float resolucion= 880; //pulsos por vuelta del encoder Motor izq
const float dist_entre_ruedas= 0.118;//distancia entre ruedas sobre el eje
// variables definidas como volatile para interrupciones
volatile long cont_izq_A = 0;  //contador de pulsos totales encoder A motor izquierda
volatile long pulsos_inter_izq = 0;  //contador de pulsos encoder A motor izquierda en un intervalo de tiempo (velocidad)
volatile long pulsos_inter_izq2 = 0;  //contador de pulsos encoder A motor izquierda en un intervalo de tiempo (distancia diferencial)

volatile long cont_dech_A = 0;  //contador de pulsos totales encoder A motor derecho
volatile long pulsos_inter_dech = 0;  //contador de pulsos encoder A motor derecho en un intervalo de tiempo (velocidad)
volatile long pulsos_inter_dech2 = 0;  //contador de pulsos encoder A motor derecho en un intervalo de tiempo (distancia diferencial)

// variables 
float dist_rueda_izq = 0; //distancia recorrida por la rueda izquierda
float velocidad_rueda_izq = 0;
float rpm_rueda_izq = 0;

float dist_rueda_dech = 0; //distancia recorrida por la rueda derecho
float velocidad_rueda_dech = 0;
float rpm_rueda_dech = 0;

float x = 0;
float y = 0;
float theta = 0;  // 90 grados en radianes (pi/2)

int valor_PWM_izq = 0;       // Velocidad actual (0-255)
int valor_PWM_dech = 0;       // Velocidad actual (0-255)
unsigned long tiempo_aceleracion1 = 0; // variable para intervalo aceleracion y deceleracion PWM_izq
unsigned long tiempo_aceleracion2 = 0; // variable para intervalo aceleracion y deceleracion PWM_dech


int estadoA_izq, estadoAnteriorA_izq;
int estadoA_dech, estadoAnteriorA_dech;
volatile bool direccion_mot_izq = HIGH;
volatile bool direccion_mot_dech = HIGH;

//----------------------------------------------------------------------------------------------
// variables PID discreto
float Setpoint; //setpoint
//float PV; //variable proceso (contiene lo que sale por PWM)
//float CV; //salida
float CVmenos1_izq;
float error_izq;
float errormenos1_izq;
float errormenos2_izq;
float CVmenos1_dech;
float error_dech;
float errormenos1_dech;
float errormenos2_dech;
float kp = 4;
float ki = 0.1;
float kd = 0.001;
float Tm = 0.1; // tiempo muestreo 100 ms

//----------------------------------------------------------------------------------------------
// Definimos una matriz bidimensional para representar una matriz LED de 12x8.
ArduinoLEDMatrix matrix;
byte frame1[8][13] = {
  { 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0 },
  { 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0 },
  { 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0 },
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0 },
  { 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0 },
  { 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0 },
  { 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0 },
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
};
/*uint8_t frame2[104] = {
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ,
   0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0 ,
   0, 0, 1, 7, 1, 7, 1, 7, 1, 7, 1, 1, 0 ,
   0, 0, 1, 7, 1, 7, 1, 7, 1, 7, 1, 1, 0 ,
   0, 0, 1, 7, 1, 7, 1, 7, 1, 7, 1, 1, 0 ,
   0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0 ,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 
};*/

uint8_t frame2[104] = {
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 
};

// Creamos un objeto Modulino distance
ModulinoDistance distance;
int measure = 0;

// Creamos las variables Sensor Sonar URM37
// # Conexiones:
// #       Vcc (Arduino)      -> Pin 1 VCC (URM V5.0)
// #       GND (Arduino)      -> Pin 2 GND (URM V5.0)
// #       Pin 3 (Arduino)    -> Pin 3 ECHO (URM V5.0)
// #       Pin 1 TX1 (Arduino)  -> Pin 4 RXD (URM V5.0)
// #       Pin 0 RX0 (Arduino)  -> Pin 5 TXD (URM V5.0)
// # Modo de trabajo:  Automatic measurement model.
int URECHO = 3; // PWM Output 0－50000us，cada 50us que tarda en llegar es 1cm
unsigned int Distance = 0;
uint8_t AutomaticModelCmd[4] = {0x44, 0x02, 0xaa, 0xf0}; // Configuracion para Automatic measurement model

// Creamos un objeto Lidar8x8
DFRobot_MatrixLidar_I2C Lidar8x8(0x32); //creamos la un objeto de la clase 
//uint16_t buf[64];
std::array<uint16_t, 64> buf; // necesitamos este dato para poderlo pasar por el bridge, con uint16_t no se puede
std::array<uint16_t, 64> cat; // es la misma que la anterior pero pasando solo 0,1,2,3 dependiendo de la distancia
int izq = 0;
int cen = 0;
int der = 0;

int rpm_avance_izq= 0;  //rpm que queremos asignar al motor izquierdo
int rpm_avance_dech= 0; //rpm que queremos asignar al motor derecho

void setup() 
{
  //Inicializa el puente con linux
        Bridge.begin();  
  // Iniciamos Serial Monitor
        Monitor.begin();

  // -----------------------------ODOMETRIA Y MOTORES--------------------------------------------------------------------------
  //Definimos entradas y salidas odometria y motores
        pinMode(encAmot_izq, INPUT);
        pinMode(encBmot_izq, INPUT);
        pinMode(encAmot_dech, INPUT);
        pinMode(encBmot_dech, INPUT);
        pinMode(Sentido_mot_izq, OUTPUT);
        pinMode(Sentido_mot_dech, OUTPUT);
      
      //attachInterrupt(digitalPinToInterrupt(encAmot_izq), Pulsos_mot_izq, RISING);//precision simple flanco de subida
      //attachInterrupt(digitalPinToInterrupt(encAmot_dech), Pulsos_mot_dech, RISING);//precision simple flanco de subida
        attachInterrupt(digitalPinToInterrupt(encAmot_izq), ISR_mot_izq, CHANGE); //Definimos interrupción precision doble flanco de subida y bajada
        attachInterrupt(digitalPinToInterrupt(encAmot_dech), ISR_mot_dech, CHANGE); //Definimos interrupción precision doble flanco de subida y bajada
      
  // Esperamos a que python comience para sincronizar
        boolean start = false;
        while(!start)
        {
          Bridge.call("linux_started").result(start);
        }
  // -----------------------------SENSORES--------------------------------------------------------------------------
  // Iniciamos Modulino system y Sensor de distancia
        Modulino.begin();
        distance.begin();

  // Iniciamos URM37
        AutomaticModelSetup();        //Automatic measurement model set
        delay(3000);                   // wait for sensor setup

  // Iniciamos la matriz led de Arduino UNO Q
        matrix.begin();
        matrix.setGrayscaleBits(3);
        pinMode(STAT, INPUT);  // configuramos el pin 13 como entrada si esta enchufado o no la fuente de alimentación

  // Iniciamos Lidar8x8

        for (int intento = 0; intento < 4; intento++) 
        {
            if (Lidar8x8.begin() == 0) 
            {
                Monitor.println("...");
                Monitor.println("LIDAR iniciado correctamente.");
                for (int intento = 0; intento < 6; intento++) 
                {
                      if (Lidar8x8.setRangingMode(eMatrix_8X8) == 0) 
                      {
                            Monitor.println("Configuracion Lidar 8x8 cargada OK.");
                            break;
                      }
        
                      Monitor.print("Error al cargar configuracion 8x8. Intento ");
                      Monitor.print(intento + 1);
                      Monitor.println("/4");
        
                      delay(500);   // Pequeña pausa antes de reintentar
                }
                break;
            }
            else
            {    
                Monitor.print("Error iniciando LIDAR. Intento ");
                Monitor.print(intento + 1);
                Monitor.println("/4");
            }
        
            delay(1000);   // Pequeña pausa antes de reintentar
        }
    // Iniciamos el array buf (para saber que se pasan bien los datos por el bridge)
        for (size_t i = 0; i < buf.size(); ++i) {
            buf[i] = static_cast<uint16_t>(i);
        }
}

void loop() 
{

  // Definimos la variable tiempoActual que la sincronizamos con el timer (reloj del micro)

      unsigned long tiempoActual = millis();


  // ***********************ODOMETRIA**************************************************************************************************************************  
  
      Velocidad_Encoders(veintemilisegundos);  // calcula la velocidad en un intervalo
      Odometria(diezmilisegundos); // calcula x y theta 
 
      dist_rueda_izq = DistanciaTotal_Encoder(cont_izq_A); // distancia total recorrida por rueda izquierda (robot visto desde atras)
      dist_rueda_dech = DistanciaTotal_Encoder(cont_dech_A); // distancia total recorrida por rueda izquierda (robot visto desde atras)
    

  
  // ***********************SENSORES***************************************************************************************************************************
  // intervalo fijado para lectura de sensores 200 milisegundos para no sobrecargar microprocesador

  
      if (tiempoActual - tiempo_lectura_Sigue >= 0.5)  //necesito que el tiempo de lectura de sigue-linea sea muy rapido, en tiempo real
      {
          tiempo_lectura_Sigue = tiempoActual;  // tomara una medida cada 0.5 ms
        
          // Si el robot va a 70rpm, se mueve 20cm en un segundo. Si tomamos dos medidas cada milisegundo, obtenemos 2000 medidas por segundo. 
          // En 20 cm obtenemos una medida cada 0,01cm  (20/2000=0,01cm), de esta forma nos acercamos a tiempo real de toma de valores
          // -------------------------------------------------------------------------------------------------------
          // Sensores Sigue-Lineas entradas A2 A3 A4 A5
          // Robot con motores hacia atras
        
              sensorValueA2 = analogRead(A2); // Leer pin analógico A2
              sensorValueA3 = analogRead(A3); // Leer pin analógico A3
              sensorValueA4 = analogRead(A4); // Leer pin analógico A4
              sensorValueA5 = analogRead(A5); // Leer pin analógico A5
        
              // la salida anoligica obtiene valores desde 0 a 1023
              // Si quiero voltaje 0 a 5v multiplico 1023*0.004882 = 5v
              // Si quiero voltaje 0 a 3,3v multiplico 1023*0.00323 = 3,3v          
      }
        
  
      if (tiempoActual - tiempo_lectura >= cienmilisegundos)  
      {
          tiempo_lectura = tiempoActual;  // tomara una medida cada 100 ms
       
          // -------------------------------------------------------------------------------------------------------
          // Sensor Lidar 64 puntos (8x8)
          // recoge los datos en una variable buf[64]
        
              Lidar8x8.getAllData(buf.data());  // minimo tiempo recogida de datos cada 100 ms
             
          // -------------------------------------------------------------------------------------------------------
          // Sensor Modulino Distance
              if (distance.available()) 
              {
                    measure = distance.get(); //devuelve la distancia en mm (minimo tiempo recogida de datos cada 10 ms)
              }else
              {
                    measure = 1200;
              }
              
          // -------------------------------------------------------------------------------------------------------
          // Sensor Sonar URM37
              AutomaticMeasurement();  // recogemos medidas en cm (minimo tiempo recogida datos 100 ms)
        
            
          // -------------------------------------------------------------------------------------------------------
          // Si el pin 13 esta a nivel bajo y si es asi se enciende la matriz led estado de carga
        
              estado = digitalRead(STAT);  // pin estado LOW si esta cargando la bateria
        
              if (estado == LOW) 
              {
                    matrix.renderBitmap(frame1,8,13);  // Mostrar el patrón en la matriz LED en este caso una flecha
                    shiftLeftLoop(frame1);  // mover la flecha hacia la izquierda cuando el robot carga
              }
              else
              {
                    matrix.draw(frame2);  // Mostrar una bateria en la matriz led
                   //matrix.clear();
              }
        
      }

    /* 
      // imprime por serial monitor según el intervalo fijado
      if (tiempoActual - tiempo_monitor >= dossegundos)  
      {

          //---------------------------ODOMETRIA Y MOTORES------------------------------------------------------------------------------------------------------------------
              Monitor.println("Motor izq:          Motor dech:"); //Monitor.println(" ");
              Monitor.print(cont_izq_A); Monitor.print("  ----------  "); Monitor.print(cont_dech_A); Monitor.println("      pulsos"); //Monitor.println(" ");
              Monitor.print(dist_rueda_izq); Monitor.print(" ----------  "); Monitor.print(dist_rueda_dech); Monitor.println("      metros"); //Monitor.println(" ");
              Monitor.print(rpm_rueda_izq); Monitor.print(" ----------  "); Monitor.print(rpm_rueda_dech); Monitor.println("      rpm");// Monitor.println(" ");
              Monitor.print(velocidad_rueda_izq); Monitor.print(" ----------  "); Monitor.print(velocidad_rueda_dech); Monitor.println("      m/s");// Monitor.println(" ");
              Monitor.print(valor_PWM_izq); Monitor.print(" ----------  "); Monitor.print(valor_PWM_dech); Monitor.println("      0-255");// Monitor.println(" ");
              Monitor.print(direccion_mot_izq); Monitor.print(" ----------  "); Monitor.print(direccion_mot_dech); Monitor.println("      direccion"); //Monitor.println(" ");
              Monitor.println("-------------------------------"); //Monitor.println(" ");
              Monitor.print("    x: "); Monitor.print(x); Monitor.println(" ");
              Monitor.print("    y: "); Monitor.print(y); Monitor.println(" ");
              Monitor.print("theta: ");  Monitor.print(theta); Monitor.println(" ");
              Monitor.println("-------------------------------");
        
          //---------------------------SENSORES------------------------------------------------------------------------------------------------------------------
          // Imprimimos por pantalla los valores de los sensores sigue-lineas
              Monitor.print("A2      "); Monitor.print("A3      "); Monitor.print("A4      "); Monitor.println(" A5");
              Monitor.print(sensorValueA2*0.004882); Monitor.print(" V  "); 
              Monitor.print(sensorValueA3*0.004882); Monitor.print(" V  "); // Mostrar valor en Monitor Serie 
              Monitor.print(sensorValueA4*0.004882); Monitor.print(" V  "); // Si quiero voltaje 0 a 5v multiplico 1023*0,004882 = 5v
              Monitor.print(sensorValueA5*0.004882); Monitor.println(" V"); // Si quiero voltaje 0 a 3,3v multiplico 1023*0,00323 = 3,3v
              Monitor.println("  ");
              Monitor.println("------------------------------");
          // Imprimimos por pantalla el valor del sensor Modulino Distance
              Monitor.print("Distancia Modulino: "); Monitor.print(measure/10); Monitor.println(" cm");
              Monitor.println("------------------------------");
        
          // Imprimimos por pantalla el valor del sensor Sonar URM37
              Monitor.print("Distancia Sonar = ");
              Monitor.print(Distance);
              Monitor.println("cm");
              Monitor.println("------------------------------");
        
          // Imprimimos por pantalla los valores del sensor Lidar 8x8
              for (int i = 0; i < 8; i++) {
                  Monitor.print("Y");
                  Monitor.print(i);
                  Monitor.print(": ");
              
                  for (int j = 0; j < 8; j++) {
                      Monitor.print(buf[i * 8 + (7 - j)]);
                      Monitor.print(",");
                  }
              
                  Monitor.println();
              }
              Monitor.println("  ");
              Monitor.println("------------------------------");
          
          // Imprimimos por pantalla los valores del sensor Lidar 8x8
        
              if (estado == LOW) 
              {
                    Monitor.println("Fuente conectada, batería cargador ... ");
                    Monitor.println("------------------------------");
              }
              else
              {
                    Monitor.println("Robot autonomo, fuente desconectada");
                    Monitor.println("------------------------------");
              }

          
        tiempo_monitor = tiempoActual;
      }  */
      //delay(2000);  // utilizamos millis() porque delay para el programa


    // *********************SIGUE OBSTACULOS************************************************************************************************************************
    // Con LIDAR 8X8
    /*  POSICION DEL ARRAY DEL SENSOR SEN0628 LIDAR 8X8
    
     7  6  5  4  3  2  1  0
    15 14 13 12 11 10  9  8
    23 22 21 20 19 18 17 16
    31 30 29 28 27 26 25 24
    39 38 37 36 35 34 33 32
    47 46 45 44 43 42 41 40 
    55 54 53 52 51 50 49 48 
    63 62 61 60 59 58 57 56 
    
    */
          // cambia los valores de distancia por 0, 1, 2, 3
          for (int i = 0; i < 64; i++) {
            
                int d = buf[i];   // distancia original
            
                if (d < 500) {
                    cat[i] = 0;
                } else if (d < 1200) {
                    cat[i] = 1;
                } else if (d < 2000) {
                    cat[i] = 2;
                } else {
                    cat[i] = 3;
                }
          }

          // cuenta los ceros que hay en cada columna para saber donde ir
          izq = 0;
          der = 0;
          cen = 0; 
          for (int i = 0; i < 64; i++) {
          
              int fila = i / 8;  //fila no se utiliza
              int col  = 7 - (i % 8);   // CORREGIDO
          
              if (cat[i] == 0) {  // distancia ideal (hasta 400 mm)
          
                  if (col <= 2) izq++;       // columnas 0,1,2 → izquierda real
                  else if (col <= 4) cen++;  // columnas 3,4 → centro real
                  else der++;                // columnas 5,6,7 → derecha real
              }
          }


   
          if ( cen > 8 ) {

              // girar izquierda
              digitalWrite(Sentido_mot_izq, HIGH); //hacia delante nivel alto E1
              digitalWrite(Sentido_mot_dech, HIGH); //hacia delante nivel bajo E2
        
              analogWrite(PWM_mot_izq, 0);
              analogWrite(PWM_mot_dech, 0);
                
          }
          else if (izq < 6 && der < 6) // si se cumplen las dos no se mueve
          {
              digitalWrite(Sentido_mot_izq, HIGH); //hacia delante nivel alto E1
              digitalWrite(Sentido_mot_dech, HIGH); //hacia delante nivel bajo E2
        
              analogWrite(PWM_mot_izq, 0);
              analogWrite(PWM_mot_dech, 0);
            
          }
          else if (izq > der) {

              // girar izquierda
              digitalWrite(Sentido_mot_izq, HIGH); //hacia delante nivel alto E1
              digitalWrite(Sentido_mot_dech, HIGH); //hacia delante nivel bajo E2
        
              analogWrite(PWM_mot_izq, 70);
              analogWrite(PWM_mot_dech, 70);
                
          }
          else if (der > izq) {
            
              // girar derecha
              digitalWrite(Sentido_mot_izq, LOW); //hacia delante nivel alto E1
              digitalWrite(Sentido_mot_dech, LOW); //hacia delante nivel bajo E2
        
              analogWrite(PWM_mot_izq, 70);
              analogWrite(PWM_mot_dech, 70);
          }
          

   

            
          // Saca en la matriz de led lo que esta viendo el LIDAR 8x8
           for (int i = 0; i < 64; i++) 
           {
          
              int fila = i / 8;          // 0–7
              int col  = 7 - (i % 8);    // 0–7 (corregido según tu orientación)
          
              // Ahora col_led coincide EXACTAMENTE con col
              int col_led = col;         // 0–7
          
              int cat_val = cat[i];      // 0–3
          
              // Intensidad invertida: cerca = más luz
              int intensidad = 7 - (cat_val * 2);
          
              int index_led = fila * 13 + col_led;  // índice lineal 0–103
          
              frame2[index_led] = intensidad;
          }


        
      // ***********************CONTROL MOTORES************************************************************************************************************************
  /*
          if (millis()>= retraso_motores){
          // esperamos 2 segundos a que empieze el program y le damos velocidad a los motores
              if (tiempoActual - tiempo_aceleracion1 >= 0.00005) 
              {
                  tiempo_aceleracion1 = tiempoActual;
                          // 56 rpm son 0,2 m/s (78 pwm)
                          // 84 rpm son 0,3m/s buena velocidad para un robot diferencial (110 pwm)
                          // 114 rpm son 0,4m/s (150 pwm)
                          // 142 rpm son 0,5m/s (182 pwm)
                          // 170 rpm son 0,6m/s (239 pwm)
                          // 198 rmp don 0,7m/s (255 pwm)
                  if ( rpm_rueda_izq < rpm_avance_izq  ) {    
                      valor_PWM_izq ++; //acelera
                  }else
                  {
                      valor_PWM_izq --;  //frena
                  }
                  if ( rpm_rueda_dech < rpm_avance_dech  ) {    
                      valor_PWM_dech ++; 
                  }else
                  {
                      valor_PWM_dech --;
                  }
                
                   analogWrite(PWM_mot_izq, valor_PWM_izq);
                   analogWrite(PWM_mot_dech, valor_PWM_dech);
                    
               }
          } */

      // ***********************PID MOTORES************************************************************************************************************************
    
      // Setpoint: rpm a las que queremos llegar
      //   PID_izq (84, valor_PWM_dech, 100, PWM_mot_dech, rpm_rueda_dech); // parametros (Setpoint (rpm), Salida_PWM, Tiempo muestreo, PIN_PWM, rpm_sensor_encoder)
      //   PID_dech (84, valor_PWM_izq, 100, PWM_mot_izq, rpm_rueda_izq); // parametros (Setpoint (rpm), Salida_PWM, Tiempo muestreo, PIN_PWM, rpm_sensor_encoder)
      
             // 56 rpm son 0,2 m/s (78 pwm)
             // 84 rpm son 0,3m/s buena velocidad para un robot diferencial (110 pwm)
             // 114 rpm son 0,4m/s (150 pwm)
             // 142 rpm son 0,5m/s (182 pwm)
             // 170 rpm son 0,6m/s (239 pwm)
             // 198 rmp don 0,7m/s (255 pwm)

  
      //*********************************************************************************************************************************************************
      // enviamos los datos por el puente Bridge a la parte del microprocesador linux
        
      if( tiempoActual- tiempo_anterior3 >= doscientosmilisegundos) // envia los datos por el bridge 5 veces segundo (cada 200ms)
      {   
        if (!(rpm_rueda_izq == 0 && rpm_rueda_dech == 0))
        {
            Bridge.notify("recibir_pose", x, y, theta);
        }
        Bridge.notify("recibir_modulino", measure);
        Bridge.notify("recibir_sonar", Distance);
        Bridge.notify("recibir_siguelineas", sensorValueA2, sensorValueA3, sensorValueA4, sensorValueA5);
        Bridge.notify("recibir_Lidar8X8", cat);
        tiempo_anterior3 = tiempoActual;
      }
      //*********************************************************************************************************************************************************

          
}  // final de funcion void loop()


void PID_izq (int Setpoint, int Salida, int tiempomuestreo, int PinPWM, float rpm_rueda) // Setpoint (rpm), salida PWM, 100ms tiempo muestreo
{
    unsigned long tiempoActual = millis();

    if (tiempoActual - tiempo_aceleracion1 >= tiempomuestreo)  // metemos el tiempo de muestreo que es 100 ms
    {
          tiempo_aceleracion1 = tiempoActual;

      //ERROR
          error_izq = Setpoint - rpm_rueda;  // error
      //ECUACION DIFERENCIAL PID
          Salida = CVmenos1_izq + ((kp + kd/Tm)*error_izq) + ((-kp + ki*Tm - 2*kd/Tm)*errormenos1_izq) + ((kd/Tm)*errormenos2_izq);
          CVmenos1_izq = Salida;
          errormenos2_izq = errormenos1_izq;
          errormenos1_izq = error_izq;
      // SATURACION DEL PID
          if (Salida > 200) { Salida = 200; }
          if (Salida < 50) { Salida = 50; }

          analogWrite(PinPWM, Salida);
    }
}

void PID_dech (int Setpoint, int Salida, int tiempomuestreo, int PinPWM, float rpm_rueda) // Setpoint (rpm), salida PWM, 100ms tiempo muestreo
{
    unsigned long tiempoActual = millis();
  
    if (tiempoActual - tiempo_aceleracion2 >= tiempomuestreo)  // metemos el tiempo de muestreo que es 100 ms
    {
          tiempo_aceleracion2 = tiempoActual;

      //ERROR
          error_dech = Setpoint - rpm_rueda;  // error
      //ECUACION DIFERENCIAL PID
          Salida = CVmenos1_dech + ((kp + kd/Tm)*error_dech) + ((-kp + ki*Tm - 2*kd/Tm)*errormenos1_dech) + ((kd/Tm)*errormenos2_dech);
          CVmenos1_dech = Salida;
          errormenos2_dech = errormenos1_dech;
          errormenos1_dech = error_dech;
      // SATURACION DEL PID
          if (Salida > 200) { Salida = 200; }
          if (Salida < 50) { Salida = 50; }

          analogWrite(PinPWM, Salida);
    }
}

void ISR_mot_izq() 
{
  cont_izq_A++; // Incrementa el contador en cada flanco de encoder A motor izquierda
  pulsos_inter_izq++;
  pulsos_inter_izq2++;
  
  estadoA_izq = digitalRead(encAmot_izq);
  // Si el estado de A cambió, detectamos la dirección con B
  if (estadoA_izq != estadoAnteriorA_izq) {
    if (digitalRead(encBmot_izq) != estadoA_izq) {
      direccion_mot_izq= HIGH; // Sentido hacia delante
    } else {
      direccion_mot_izq= LOW; // Sentido hacia atras
    }
  }
  estadoAnteriorA_izq = estadoA_izq;
  
}

void ISR_mot_dech() 
{
  cont_dech_A++; // Incrementa el contador en cada flanco de encoder A motor izquierda
  pulsos_inter_dech++;
  pulsos_inter_dech2++;

  estadoA_dech = digitalRead(encAmot_dech);
  // Si el estado de A cambió, detectamos la dirección con B
  if (estadoA_dech != estadoAnteriorA_dech) {
    if (digitalRead(encBmot_dech) != estadoA_dech) {
      direccion_mot_dech= LOW; // Sentido hacia atras (el motor esta alreves)
    } else {
      direccion_mot_dech= HIGH; // Sentido hacia delante (el motor esta alreves)
    }
  }
  estadoAnteriorA_dech = estadoA_dech;
  
}

void Velocidad_Encoders(unsigned long intervalo)
{
  unsigned long tiempoActual = millis();
  
  if (tiempoActual - tiempo_anterior >= intervalo) 
  {
    // Calcula RPM motor izquierdo
    rpm_rueda_izq = pulsos_inter_izq / resolucion * (60.0 / (intervalo / 1000.0));
    // Calcula Velocidad m/s rueda izquierda
    velocidad_rueda_izq = (rpm_rueda_izq * pi * diametro) / 60;
    
    // Reiniciar contador
    pulsos_inter_izq = 0;

    // Calcula RPM motor derecho
    rpm_rueda_dech = pulsos_inter_dech / resolucion * (60.0 / (intervalo / 1000.0));
    // Calcula Velocidad m/s rueda derecha
    velocidad_rueda_dech = (rpm_rueda_dech * pi * diametro) / 60;
       
    // Reiniciar contador
    pulsos_inter_dech = 0;

    // actualiza el tiempo
    tiempo_anterior = tiempoActual;
  }
   
}

// calcula una distancia en un intervalo de tiempo muy pequeño para obtener la POSE(x,y,theta) del robot
void Odometria(unsigned long intervalo)
{

  float distpulso = pi*diametro/resolucion;  //distancia recorrida por cada pulso encoder en metros
                                            //pi*0.06/374 trocito circunferencia rueda 6cm diametro (374pulsos una vuelta)
                                            //cada pulso 
  unsigned long tiempoActual = millis();
  
  if (tiempoActual - tiempo_anterior2 >= intervalo) 
  {
    
      float dX_izq = pulsos_inter_izq2 * distpulso;  //distancia en metros recorrida por la rueda
                                                     //cada pulso multiplicado por el trocito de distancia recorrida cada pulso
      float dX_dech = pulsos_inter_dech2 * distpulso;  //distancia en metros recorrida por la rueda
                                                     //cada pulso multiplicado por el trocito de distancia recorrida cada pulso

      if (direccion_mot_izq == LOW){ dX_izq = -dX_izq; } // si el coche va en sentido hacia atras
      if (direccion_mot_dech == LOW){ dX_dech = -dX_dech; } // si el coche va en sentido hacia atras

      // Calculamos ODOMETRIA -------------------------------------------------------------
      float dX_centro_robot=(dX_izq + dX_dech)/2; //calculo de distancia recorrida por el punto central del eje del robot
      float d_theta= (dX_dech-dX_izq)/dist_entre_ruedas; //calculo de tetha

      if (!(rpm_rueda_izq == 0 && rpm_rueda_dech == 0))
      {
          theta += (d_theta/2) ; // (d_theta/2) es una correccion que hace que mejora la odometria, solo necesitamos que se haga si la velocidad es distina de cero
      }
      theta += (d_theta/2) ; // (d_theta/2) es una correccion que hace que mejora la odometria
      x += dX_centro_robot*cos(theta);  // Calculo posicion x,y
      y += dX_centro_robot*sin(theta);  // Se trabaja en radianes en programacion en C
      // ----------------------------------------------------------------------------------
    
      
      pulsos_inter_izq2= 0;
      pulsos_inter_dech2= 0;
      tiempo_anterior2 = tiempoActual;
    
  }
  
}

float DistanciaTotal_Encoder(long contador_pulsos)
{

  float distpulso = pi*diametro/resolucion;  //distancia recorrida por cada pulso encoder en metros
                                            //pi*0.06/374 trocito circunferencia rueda 6cm diametro (374pulsos una vuelta)
                                            //cada pulso 
  float distancia = contador_pulsos * distpulso;  //distancia total en metros recorrida por la rueda
                                                  //cada pulso multiplicado por el trocito de distancia recorrida cada pulso
  return distancia; //devuelve el valor de la distancia recorrida

}

// *******************************************************************************************
// Funciones de Sensor Sonar URM37
                                                                              // funcion para medir lo largo que es el pulso en microsegundos
unsigned long pulseIn_Q(int pin, bool state, unsigned long timeout = 1000000) // timeout 1 segundo porque son microsegundos (us)
                                                                              // recordar que cada 50us es un centimetro
{
    unsigned long start = micros();

    // Esperar a que empiece el pulso
    while (digitalRead(pin) != state) 
    {
        if (micros() - start > timeout) // timeout 1 segundo
        {
          Monitor.print("Esperando a empiece pulso");
          return 0;
        }
    }

    // Pulso ha empezado
    unsigned long pulseStart = micros();

    // Esperar a que termine el pulso
    while (digitalRead(pin) == state) 
    {
        if (micros() - pulseStart > timeout) return 0;
    }

    return micros() - pulseStart; // enviamos la duración del pulso en microsegundos (us)
}

void AutomaticModelSetup(void)
{
  pinMode(URECHO, INPUT);                     
  for (int i = 0; i < 4; i++)
  {
    Monitor.write(AutomaticModelCmd[i]);// Enviamos Automatic measurement model command {0x44, 0x02, 0xaa, 0xf0}
  }
}
void AutomaticMeasurement(void)
{
  long DistanceMeasured = pulseIn_Q(URECHO, LOW); // recogemos la duración del pulso en microsegundos
  if (DistanceMeasured >= 50000) // Si la duración del pulso supera los 0,05 segundos la medida no vale (>10metros).
  {
    Monitor.print("Invalid");
  }
  else
  {
    Distance = DistanceMeasured / 50;       // recordar que cada 50us es un centimetro
      //if (abs(Distance - DistanceAnt) > 3 )  // solo imprime la distancia si a cambiado en 3 unidades
      //{
          //Monitor.print("Distancia Sonar=");
          //Monitor.print(Distance);
          //Monitor.println("cm");
          //Monitor.println("------------------------------");
          //DistanceAnt = Distance;
      //}
  }  
  
}

// *******************************************************************************************
// MOVER TEXTO HACIA LA DERECHA UNA COLUMNA
void shiftRightLoop(byte frame[8][13]) {
    for (int y = 0; y < 8; y++) {
        byte last = frame[y][12];  // guardamos la última columna
        for (int x = 12; x > 0; x--) {
            frame[y][x] = frame[y][x - 1];
        }
        frame[y][0] = last;        // la columna que salió vuelve al inicio
    }
}
// MOVER TEXTO HACIA LA IZQUIERDA UNA COLUMNA
void shiftLeftLoop(byte frame[8][13]) {
    for (int y = 0; y < 8; y++) {
        byte first = frame[y][0];
        for (int x = 0; x < 12; x++) {
            frame[y][x] = frame[y][x + 1];
        }
        frame[y][12] = first;
    }
}






