from arduino.app_utils import * 
import time 


# Esta función será llamada desde el MCU para sincronizar el comienzo
def linux_started():
    print(" \n\n\n======== Comienza el programa Phyton ========\n ")
    return True
  
# Esta función será llamada desde el MCU 
def recibir_pose(valorX: float, valorY: float, valorTheta: float):
    print(f"x: {valorX:.2f} y: {valorY:.2f} tetha: {valorTheta:.2f}")
    print(" \n\n==================================\n ")
def recibir_modulino(valorModulino: float):
    print(f"Distancia Modulino: {valorModulino/10:.2f} cm")
def recibir_sonar(valorSonar: float):
    print(f"Distancia Sonar: {valorSonar:.2f} cm")
    print(" \n\n==================================\n ")
    time.sleep(1)

Bridge.provide("linux_started", linux_started)
Bridge.provide("recibir_pose", recibir_pose)
Bridge.provide("recibir_modulino", recibir_modulino)
Bridge.provide("recibir_sonar", recibir_sonar)


App.run()
  

