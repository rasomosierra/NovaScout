#include <Arduino_RouterBridge.h>

// Definimos constantes de tiempo en milisegundos
#define unmilisegundo 10
#define diezmilisegundos 10
#define veintemilisegundos 20
#define unsegundo 1000
#define cincosegundos 5000
// Definimos las entradas en Arduino (visto desde detras del robot)
// Entrada encoder 
#define encAmot_izq  8 
#define encBmot_izq  7 
#define encAmot_dech  4 
#define encBmot_dech  2
// Definimos las salidas en Arduino
// Salidas PWM
#define PWM_mot_dech  9
#define PWM_mot_izq  10
#define Sentido_mot_dech  11
#define Sentido_mot_izq  12


// Datos necesarios Encoder y rueda
const float pi= 3.14159;
const float diametro=0.0675; //diametro de la rueda en metros
const float resolucion= 880; //pulsos por vuelta del encoder Motor izq
const float dist_entre_ruedas= 0.118;//distancia entre ruedas sobre el eje

// Datos necesarios para fijar un intervalo de tiempo de medicion
unsigned long tiempo_anterior = 0; // variable para intervalo para medir velocidad
unsigned long tiempo_anterior2 = 0; // variable para intervalo para medir distancia diferencial
unsigned long tiempo_anterior3 = 0; // variable para intervalo para medir distancia diferencial
unsigned long tiempo_monitor = 0; // variable para intervalo sacar datos por serial monitor
unsigned long retraso_motores = 10000; // variable para intervalo sacar datos por serial monitor

// variables definidas como volatile para interrupciones
volatile long cont_izq_A = 0;  //contador de pulsos totales encoder A motor izquierda
volatile long pulsos_inter_izq = 0;  //contador de pulsos encoder A motor izquierda en un intervalo de tiempo (velocidad)
volatile long pulsos_inter_izq2 = 0;  //contador de pulsos encoder A motor izquierda en un intervalo de tiempo (distancia diferencial)

volatile long cont_dech_A = 0;  //contador de pulsos totales encoder A motor derecho
volatile long pulsos_inter_dech = 0;  //contador de pulsos encoder A motor derecho en un intervalo de tiempo (velocidad)
volatile long pulsos_inter_dech2 = 0;  //contador de pulsos encoder A motor derecho en un intervalo de tiempo (distancia diferencial)

// variables 
float dist_rueda_izq = 0; //distancia recorrida por la rueda izquierda
float velocidad_rueda_izq = 0;
float rpm_rueda_izq = 0;

float dist_rueda_dech = 0; //distancia recorrida por la rueda derecho
float velocidad_rueda_dech = 0;
float rpm_rueda_dech = 0;

float x = 0;
float y = 0;
float theta = 0;  // 90 grados en radianes (pi/2)

int valor_PWM_izq = 0;       // Velocidad actual (0-255)
int valor_PWM_dech = 0;       // Velocidad actual (0-255)
unsigned long tiempo_aceleracion = 0; // variable para intervalo aceleracion y deceleracion PWM


int estadoA_izq, estadoAnteriorA_izq;
int estadoA_dech, estadoAnteriorA_dech;
volatile bool direccion_mot_izq = HIGH;
volatile bool direccion_mot_dech = HIGH;

void setup() 
{
  
  Monitor.begin(); //Inicializa el Serial Monitor
     
  pinMode(encAmot_izq, INPUT);
  pinMode(encBmot_izq, INPUT);
  pinMode(encAmot_dech, INPUT);
  pinMode(encBmot_dech, INPUT);
  pinMode(Sentido_mot_izq, OUTPUT);
  pinMode(Sentido_mot_dech, OUTPUT);
  
  //attachInterrupt(digitalPinToInterrupt(encAmot_izq), Pulsos_mot_izq, RISING);//precision simple flanco de subida
  //attachInterrupt(digitalPinToInterrupt(encAmot_dech), Pulsos_mot_dech, RISING);//precision simple flanco de subida
  attachInterrupt(digitalPinToInterrupt(encAmot_izq), ISR_mot_izq, CHANGE); //precision doble flanco de subida y bajada
  attachInterrupt(digitalPinToInterrupt(encAmot_dech), ISR_mot_dech, CHANGE); //precision doble flanco de subida y bajada
  
}

void loop() 
{

      unsigned long tiempoActual = millis();
    
      // le damos dirección a los motores
      digitalWrite(Sentido_mot_izq, HIGH); //hacia delante nivel alto E1
      digitalWrite(Sentido_mot_dech, LOW); //hacia delante nivel alto E1
  
        if (millis()>= retraso_motores){
        // le damos velocidad a los motores
            if (tiempoActual - tiempo_aceleracion >= 50) 
            {
                tiempo_aceleracion = tiempoActual;
                        // 56 rpm son 0,2 m/s
                        // 84 rpm son 0,3m/s buena velocidad para un robot diferencial
                        // 114 rpm son 0,4m/s 
                if ( rpm_rueda_izq < 84.00  ) {    
                    valor_PWM_izq ++; //acelera
                }else
                {
                    valor_PWM_izq --;  //frena
                }
                if ( rpm_rueda_dech < 84.00  ) {    
                    valor_PWM_dech ++; 
                }else
                {
                    valor_PWM_dech --;
                }
              
                 analogWrite(PWM_mot_izq, valor_PWM_izq);
                 analogWrite(PWM_mot_dech, valor_PWM_dech);
                  
             }
        }
    
                    
      Velocidad_Encoders(veintemilisegundos);  // calcula la velocidad en un intervalo
      Odometria(diezmilisegundos); // calcula x y theta 
 
      dist_rueda_izq = DistanciaTotal_Encoder(cont_izq_A); // distancia total recorrida por rueda izquierda (robot visto desde atras)
      dist_rueda_dech = DistanciaTotal_Encoder(cont_dech_A); // distancia total recorrida por rueda izquierda (robot visto desde atras)
    
      
      if (tiempoActual - tiempo_monitor >= unsegundo)  // imprime según el intervalo fijado (5s)
      {
        Monitor.println("Motor izq:          Motor dech:"); //Monitor.println(" ");
        Monitor.print(cont_izq_A); Monitor.print("  ----------  "); Monitor.print(cont_dech_A); Monitor.println("      pulsos"); //Monitor.println(" ");
        Monitor.print(dist_rueda_izq); Monitor.print(" ----------  "); Monitor.print(dist_rueda_dech); Monitor.println("      metros"); //Monitor.println(" ");
        Monitor.print(rpm_rueda_izq); Monitor.print(" ----------  "); Monitor.print(rpm_rueda_dech); Monitor.println("      rpm");// Monitor.println(" ");
        Monitor.print(velocidad_rueda_izq); Monitor.print(" ----------  "); Monitor.print(velocidad_rueda_dech); Monitor.println("      m/s");// Monitor.println(" ");
        Monitor.print(direccion_mot_izq); Monitor.print(" ----------  "); Monitor.print(direccion_mot_dech); Monitor.println("      direccion"); //Monitor.println(" ");
        Monitor.println("-------------------------------"); //Monitor.println(" ");
        Monitor.print("    x: "); Monitor.print(x); Monitor.println(" ");
        Monitor.print("    y: "); Monitor.print(y); Monitor.println(" ");
        Monitor.print("theta: ");  Monitor.print(theta); Monitor.println(" ");
        Monitor.println("-------------------------------");
          
        tiempo_monitor = tiempoActual;
      }
      //delay(2000);  // utilizamos millis() porque delay para el programa

}


void ISR_mot_izq() 
{
  cont_izq_A++; // Incrementa el contador en cada flanco de encoder A motor izquierda
  pulsos_inter_izq++;
  pulsos_inter_izq2++;
  
  estadoA_izq = digitalRead(encAmot_izq);
  // Si el estado de A cambió, detectamos la dirección con B
  if (estadoA_izq != estadoAnteriorA_izq) {
    if (digitalRead(encBmot_izq) != estadoA_izq) {
      direccion_mot_izq= HIGH; // Sentido hacia delante
    } else {
      direccion_mot_izq= LOW; // Sentido hacia atras
    }
  }
  estadoAnteriorA_izq = estadoA_izq;
  
}

void ISR_mot_dech() 
{
  cont_dech_A++; // Incrementa el contador en cada flanco de encoder A motor izquierda
  pulsos_inter_dech++;
  pulsos_inter_dech2++;

  estadoA_dech = digitalRead(encAmot_dech);
  // Si el estado de A cambió, detectamos la dirección con B
  if (estadoA_dech != estadoAnteriorA_dech) {
    if (digitalRead(encBmot_dech) != estadoA_dech) {
      direccion_mot_dech= LOW; // Sentido hacia atras (el motor esta alreves)
    } else {
      direccion_mot_dech= HIGH; // Sentido hacia delante (el motor esta alreves)
    }
  }
  estadoAnteriorA_dech = estadoA_dech;
  
}

void Velocidad_Encoders(unsigned long intervalo)
{
  unsigned long tiempoActual = millis();
  
  if (tiempoActual - tiempo_anterior >= intervalo) 
  {
    // Calcula RPM motor izquierdo
    rpm_rueda_izq = pulsos_inter_izq / resolucion * (60.0 / (intervalo / 1000.0));
    // Calcula Velocidad m/s rueda izquierda
    velocidad_rueda_izq = (rpm_rueda_izq * pi * diametro) / 60;
    
    // Reiniciar contador
    pulsos_inter_izq = 0;

    // Calcula RPM motor derecho
    rpm_rueda_dech = pulsos_inter_dech / resolucion * (60.0 / (intervalo / 1000.0));
    // Calcula Velocidad m/s rueda derecha
    velocidad_rueda_dech = (rpm_rueda_dech * pi * diametro) / 60;
       
    // Reiniciar contador
    pulsos_inter_dech = 0;

    // actualiza el tiempo
    tiempo_anterior = tiempoActual;
  }
   
}

// calcula una distancia en un intervalo de tiempo muy pequeño para obtener la POSE(x,y,theta) del robot
void Odometria(unsigned long intervalo)
{

  float distpulso = pi*diametro/resolucion;  //distancia recorrida por cada pulso encoder en metros
                                            //pi*0.06/374 trocito circunferencia rueda 6cm diametro (374pulsos una vuelta)
                                            //cada pulso 
  unsigned long tiempoActual = millis();
  
  if (tiempoActual - tiempo_anterior2 >= intervalo) 
  {
    
      float dX_izq = pulsos_inter_izq2 * distpulso;  //distancia en metros recorrida por la rueda
                                                     //cada pulso multiplicado por el trocito de distancia recorrida cada pulso
      float dX_dech = pulsos_inter_dech2 * distpulso;  //distancia en metros recorrida por la rueda
                                                     //cada pulso multiplicado por el trocito de distancia recorrida cada pulso

      if (direccion_mot_izq == LOW){ dX_izq = -dX_izq; } // si el coche va en sentido hacia atras
      if (direccion_mot_dech == LOW){ dX_dech = -dX_dech; } // si el coche va en sentido hacia atras

      // Calculamos ODOMETRIA -------------------------------------------------------------
      float dX_centro_robot=(dX_izq + dX_dech)/2; //calculo de distancia recorrida por el punto central del eje del robot
      float d_theta= (dX_dech-dX_izq)/dist_entre_ruedas; //calculo de tetha

      theta += (d_theta/2) ; // (d_theta/2) es una correccion que hace que mejora la odometria
      x += dX_centro_robot*cos(theta);  // Calculo posicion x,y
      y += dX_centro_robot*sin(theta);  // Se trabaja en radianes en programacion en C
      // ----------------------------------------------------------------------------------
    
      
      pulsos_inter_izq2= 0;
      pulsos_inter_dech2= 0;
      tiempo_anterior2 = tiempoActual;
    
  }
  
}

float DistanciaTotal_Encoder(long contador_pulsos)
{

  float distpulso = pi*diametro/resolucion;  //distancia recorrida por cada pulso encoder en metros
                                            //pi*0.06/374 trocito circunferencia rueda 6cm diametro (374pulsos una vuelta)
                                            //cada pulso 
  float distancia = contador_pulsos * distpulso;  //distancia total en metros recorrida por la rueda
                                                  //cada pulso multiplicado por el trocito de distancia recorrida cada pulso
  return distancia; //devuelve el valor de la distancia recorrida

}


